# Simple Movie Display (React + TypeScript + Vite)

Dit is een onderdeel van mijn kleine projectjes die ik aan het doen ben om fundamentele react code te oefenen.

Een simpele film presentatie gebasseerd op een intake opdracht die ik moest doen.
Enige wat ik hier nog aan kan doen is een component van de ster maken maar ik had het zo simpel mogelijk gehouden.
Misschien doe ik dit later nog.